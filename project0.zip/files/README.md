# Project 0

Web Programming with Python and JavaScript
This website is about transonic flows. 
It defines what a transonic flowfield is.
It describes recent numerical work in the area of research.
It describes any future work that might be carried out.
In addition, it links to ongoing activities related to this subject area 
and how to contact the author.
The files: 
project0-2.scss is the cascaded style sheet giving the look of the website.
index.html is the main html file which is the content of the page.
Other work is described in transonic1.html, transonic2.html, and transonic3.html
and all pages refer to each other.
transonicflow.png is a png image file
Readme.md is the file you are currently looking at with the description of the project